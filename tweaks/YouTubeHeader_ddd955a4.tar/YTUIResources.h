#import <UIKit/UIImage.h>

@interface YTUIResources : NSObject
+ (UIImage *)actionsheetDefaultImage;
+ (UIImage *)actionsheetUnsubscribeImage;
+ (UIImage *)bookmarkOutline;
+ (UIImage *)closedCaptionIconImage;
+ (UIImage *)iconAccountCircle;
+ (UIImage *)iconAccountCircleDark;
+ (UIImage *)iconCheckTemplateImage;
+ (UIImage *)tabIconAccountImageWithSelected:(BOOL)selected;
+ (UIImage *)xCircleOutline;
+ (UIImage *)outlineTextWithColor:(UIColor *)color;
+ (UIImage *)tintImage:(UIImage *)image color:(UIColor *)color;
+ (BOOL)delhiIconsEnabled;
@end
