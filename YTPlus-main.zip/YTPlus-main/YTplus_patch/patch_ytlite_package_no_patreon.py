#!/usr/bin/env python3
"""Patch YTLite.dylib inside a dylib, IPA, or DEB package.

The original patch_ytlite_no_patreon.py is intentionally left untouched.

Usage examples:
  python patch_ytlite_package_no_patreon.py 5.2YTLite.dylib
  python patch_ytlite_package_no_patreon.py YouTubePlus.ipa
  python patch_ytlite_package_no_patreon.py ytlite.deb --output ytlite-no-patreon.deb

If no input path is passed, the script opens a Windows file picker when
tkinter is available, then falls back to a console prompt.
"""

from __future__ import annotations

import argparse
import bz2
import copy
import gzip
import hashlib
import io
import lzma
import shutil
import struct
import subprocess
import sys
import tarfile
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path


EXPECTED_INPUT_SHA256 = (
    "406451ed1ca39f66d58fe2b1155015ec545345a865f07d5488f01568cff6774f"
)

TARGET_DYLIB_NAME = "YTLite.dylib"

AARCH64_NOP = bytes.fromhex("1f2003d5")
AARCH64_RET = bytes.fromhex("c0035fd6")
AARCH64_MOV_W0_ONE = bytes.fromhex("20008052")
AARCH64_MOV_X19_ZERO = bytes.fromhex("130080d2")


@dataclass(frozen=True)
class Patch:
    name: str
    offset: int
    expected: bytes
    replacement: bytes
    reason: str


@dataclass(frozen=True)
class Segment:
    name: str
    vmaddr: int
    vmsize: int
    fileoff: int
    filesize: int


@dataclass(frozen=True)
class MachOInfo:
    segments: list[Segment]
    symbols: dict[str, int]
    function_starts: list[int]

    def vm_to_offset(self, vmaddr: int) -> int | None:
        for segment in self.segments:
            start = segment.vmaddr
            end = segment.vmaddr + min(segment.vmsize, segment.filesize)
            if start <= vmaddr < end:
                return segment.fileoff + (vmaddr - segment.vmaddr)
        return None

    def offset_to_vm(self, offset: int) -> int | None:
        for segment in self.segments:
            start = segment.fileoff
            end = segment.fileoff + segment.filesize
            if start <= offset < end:
                return segment.vmaddr + (offset - segment.fileoff)
        return None


PATCHES = [
    Patch(
        name="skip_build_patreon_section_in_root_table",
        offset=0x135D58,
        expected=bytes.fromhex(
            "e00316aae20317aa1d1b0194fd031daa28822994f30300aa"
        ),
        replacement=AARCH64_NOP * 5 + AARCH64_MOV_X19_ZERO,
        reason="Skip building the Patreon settings section.",
    ),
    Patch(
        name="skip_add_patreon_section_to_root_table",
        offset=0x135D7C,
        expected=bytes.fromhex("e00317aae20313aa1c1b0194"),
        replacement=AARCH64_NOP * 3,
        reason="Skip adding the Patreon settings section to rootTable.",
    ),
    Patch(
        name="force_patreon_flag_check_authorized",
        offset=0x1EB64,
        expected=bytes.fromhex(
            "a889009008855339290080522001280ac0035fd6"
        ),
        replacement=AARCH64_MOV_W0_ONE + AARCH64_RET + AARCH64_NOP * 3,
        reason="Make the Patreon flag check return authorized.",
    ),
    Patch(
        name="force_patreon_token_check_authorized",
        offset=0x1EB78,
        expected=bytes.fromhex("f44fbea9fd7b01a9"),
        replacement=AARCH64_MOV_W0_ONE + AARCH64_RET,
        reason="Make the secondary token check return authorized.",
    ),
    Patch(
        name="force_patreon_runtime_gate_authorized",
        offset=0x1EEC0,
        expected=bytes.fromhex("ff0301d1f44f02a9"),
        replacement=AARCH64_MOV_W0_ONE + AARCH64_RET,
        reason="Make the shared ytpBool/ytpInt runtime gate pass.",
    ),
    Patch(
        name="default_patreon_block_registration_ready",
        offset=0x11524E0,
        expected=bytes.fromhex("01"),
        replacement=bytes.fromhex("00"),
        reason="Let tweak initialization blocks run without Patreon login.",
    ),
    Patch(
        name="dvn_patreon_logout_noop",
        offset=0x1F078,
        expected=bytes.fromhex("888900f0"),
        replacement=AARCH64_RET,
        reason="Make DVNPatreonLogout return immediately.",
    ),
    Patch(
        name="dvn_patreon_login_noop",
        offset=0x1F3D0,
        expected=bytes.fromhex("ff8302d1"),
        replacement=AARCH64_RET,
        reason="Make DVNPatreonLogin return immediately.",
    ),
    Patch(
        name="dvn_patreon_open_devices_noop",
        offset=0x21A20,
        expected=bytes.fromhex("ff8302d1"),
        replacement=AARCH64_RET,
        reason="Make DVNPatreonOpenDevices return immediately.",
    ),
]


@dataclass
class PatchReport:
    target: str
    output_md5: str
    input_sha256: str
    output_sha256: str
    results: list[str]


@dataclass
class ArMember:
    name: str
    name_field: bytes
    mtime_field: bytes
    uid_field: bytes
    gid_field: bytes
    mode_field: bytes
    data: bytes


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def md5_bytes(data: bytes) -> str:
    return hashlib.md5(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_u32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def detect_code_signature(data: bytes) -> tuple[int, int] | None:
    if len(data) < 32 or read_u32(data, 0) != 0xFEEDFACF:
        return None

    ncmds = read_u32(data, 16)
    offset = 32
    for _ in range(ncmds):
        if offset + 8 > len(data):
            return None
        cmd, cmdsize = struct.unpack_from("<II", data, offset)
        if cmd == 0x1D and offset + 16 <= len(data):
            return struct.unpack_from("<II", data, offset + 8)
        if cmdsize < 8:
            return None
        offset += cmdsize
    return None


def read_cstr(data: bytes, offset: int, limit: int) -> str:
    if offset < 0 or offset >= len(data):
        return ""
    end_limit = min(len(data), offset + limit)
    end = data.find(b"\0", offset, end_limit)
    if end < 0:
        return ""
    return data[offset:end].decode("utf-8", errors="replace")


def decode_uleb128_stream(data: bytes) -> list[int]:
    values: list[int] = []
    offset = 0
    while offset < len(data):
        shift = 0
        value = 0
        while offset < len(data):
            byte = data[offset]
            offset += 1
            value |= (byte & 0x7F) << shift
            if byte & 0x80 == 0:
                break
            shift += 7
        if value:
            values.append(value)
    return values


def parse_macho_info(data: bytes) -> MachOInfo:
    if len(data) < 32 or read_u32(data, 0) != 0xFEEDFACF:
        raise RuntimeError("Input is not a little-endian 64-bit Mach-O file.")

    ncmds = read_u32(data, 16)
    command_offset = 32
    segments: list[Segment] = []
    symtab: tuple[int, int, int, int] | None = None
    function_starts_cmd: tuple[int, int] | None = None

    for _ in range(ncmds):
        if command_offset + 8 > len(data):
            raise RuntimeError("Invalid Mach-O: truncated load command.")
        cmd, cmdsize = struct.unpack_from("<II", data, command_offset)
        if cmdsize < 8:
            raise RuntimeError("Invalid Mach-O: bad load command size.")

        if cmd == 0x19 and command_offset + 72 <= len(data):  # LC_SEGMENT_64
            name = data[command_offset + 8:command_offset + 24].split(b"\0", 1)[0]
            vmaddr, vmsize, fileoff, filesize = struct.unpack_from(
                "<QQQQ",
                data,
                command_offset + 24,
            )
            segments.append(
                Segment(
                    name=name.decode("utf-8", errors="replace"),
                    vmaddr=vmaddr,
                    vmsize=vmsize,
                    fileoff=fileoff,
                    filesize=filesize,
                )
            )
        elif cmd == 0x2 and command_offset + 24 <= len(data):  # LC_SYMTAB
            symtab = struct.unpack_from("<IIII", data, command_offset + 8)
        elif cmd == 0x26 and command_offset + 16 <= len(data):  # LC_FUNCTION_STARTS
            function_starts_cmd = struct.unpack_from("<II", data, command_offset + 8)

        command_offset += cmdsize

    text_vmaddr = next(
        (segment.vmaddr for segment in segments if segment.name == "__TEXT"),
        0,
    )

    symbols: dict[str, int] = {}
    info = MachOInfo(segments=segments, symbols=symbols, function_starts=[])

    if symtab:
        symoff, nsyms, stroff, strsize = symtab
        for index in range(nsyms):
            entry = symoff + index * 16
            if entry + 16 > len(data):
                break
            n_strx, _n_type, _n_sect, _n_desc, n_value = struct.unpack_from(
                "<IBBHQ",
                data,
                entry,
            )
            if not n_strx or n_strx >= strsize:
                continue
            name = read_cstr(data, stroff + n_strx, strsize - n_strx)
            file_offset = info.vm_to_offset(n_value)
            if name and file_offset is not None:
                symbols[name] = file_offset

    function_starts: list[int] = []
    if function_starts_cmd:
        dataoff, datasize = function_starts_cmd
        vmaddr = text_vmaddr
        for delta in decode_uleb128_stream(data[dataoff:dataoff + datasize]):
            vmaddr += delta
            file_offset = info.vm_to_offset(vmaddr)
            if file_offset is not None:
                function_starts.append(file_offset)

    function_starts.sort()
    return MachOInfo(
        segments=segments,
        symbols=symbols,
        function_starts=function_starts,
    )


def read_u32_at(data: bytes, offset: int) -> int:
    if offset < 0 or offset + 4 > len(data):
        raise RuntimeError(f"Cannot read u32 at 0x{offset:x}.")
    return struct.unpack_from("<I", data, offset)[0]


def is_adrp(word: int) -> bool:
    return (word & 0x9F000000) == 0x90000000


def is_sub_sp_sp_imm(word: int) -> bool:
    return (word & 0xFFC003FF) == 0xD10003FF


def decode_adrp_target(word: int, pc: int) -> int | None:
    if not is_adrp(word):
        return None
    immlo = (word >> 29) & 0x3
    immhi = (word >> 5) & 0x7FFFF
    imm = (immhi << 2) | immlo
    if imm & (1 << 20):
        imm -= 1 << 21
    return (pc & ~0xFFF) + (imm << 12)


def decode_ldrb_unsigned_immediate(word: int) -> tuple[int, int, int] | None:
    if (word & 0xFFC00000) != 0x39400000:
        return None
    imm = (word >> 10) & 0xFFF
    rn = (word >> 5) & 0x1F
    rt = word & 0x1F
    return imm, rn, rt


def find_masked(
    data: bytes,
    pattern: bytes,
    mask: bytes,
    start: int = 0,
    end: int | None = None,
) -> list[int]:
    if len(pattern) != len(mask):
        raise ValueError("pattern and mask lengths differ")
    if end is None:
        end = len(data)
    end = min(end, len(data))
    if start < 0 or end < start or end - start < len(pattern):
        return []

    matches: list[int] = []
    last = end - len(pattern)
    for offset in range(start, last + 1, 4):
        for index, wanted in enumerate(pattern):
            if (data[offset + index] ^ wanted) & mask[index]:
                break
        else:
            matches.append(offset)
    return matches


def dynamic_root_pair(data: bytes) -> tuple[int, int] | None:
    build_pattern = bytes.fromhex(
        "e00316aae20317aa00000000fd031daa00000000f30300aa"
    )
    build_mask = bytes.fromhex(
        "ffffffffffffffff00000000ffffffff00000000ffffffff"
    )
    add_pattern = bytes.fromhex("e00317aae20313aa00000000")
    add_mask = bytes.fromhex("ffffffffffffffff00000000")

    for build_offset in find_masked(data, build_pattern, build_mask):
        add_matches = find_masked(
            data,
            add_pattern,
            add_mask,
            start=build_offset + 0x20,
            end=build_offset + 0x80,
        )
        if add_matches:
            return build_offset, add_matches[0]
    return None


def dynamic_root_add_patch(
    data: bytes,
    patch: Patch,
    start: int = 0,
    end: int | None = None,
) -> Patch | None:
    if start == 0 and end is None:
        pair = dynamic_root_pair(data)
        if pair is None:
            return None
        offset = pair[1]
        return Patch(
            name=patch.name,
            offset=offset,
            expected=data[offset:offset + len(patch.replacement)],
            replacement=patch.replacement,
            reason=patch.reason + " (dynamically located)",
        )

    pattern = bytes.fromhex("e00317aae20313aa00000000")
    mask = bytes.fromhex("ffffffffffffffff00000000")
    matches = find_masked(data, pattern, mask, start=start, end=end)
    if not matches:
        return None
    offset = matches[0]
    return Patch(
        name=patch.name,
        offset=offset,
        expected=data[offset:offset + len(patch.replacement)],
        replacement=patch.replacement,
        reason=patch.reason + " (dynamically located)",
    )


def dynamic_root_build_patch(data: bytes, patch: Patch) -> Patch | None:
    pair = dynamic_root_pair(data)
    if pair is None:
        return None
    offset = pair[0]
    return Patch(
        name=patch.name,
        offset=offset,
        expected=data[offset:offset + len(patch.replacement)],
        replacement=patch.replacement,
        reason=patch.reason + " (dynamically located)",
    )


def symbol_patch(data: bytes, patch: Patch, info: MachOInfo) -> Patch | None:
    symbol_names = {
        "force_patreon_flag_check_authorized": "_dvnLocked",
        "force_patreon_token_check_authorized": "_dvnCheck",
        "dvn_patreon_logout_noop": "_DVNPatreonLogout",
        "dvn_patreon_login_noop": "_DVNPatreonLogin",
        "dvn_patreon_open_devices_noop": "_DVNPatreonOpenDevices",
    }
    symbol = symbol_names.get(patch.name)
    if not symbol:
        return None
    offset = info.symbols.get(symbol)
    if offset is None:
        return None

    if patch.name == "force_patreon_flag_check_authorized":
        if offset + 20 > len(data):
            return None
        if (
            is_adrp(read_u32_at(data, offset))
            and data[offset + 4:offset + 20]
            == bytes.fromhex("08855339290080522001280ac0035fd6")
        ):
            return Patch(
                patch.name,
                offset,
                data[offset:offset + len(patch.replacement)],
                patch.replacement,
                patch.reason + " (symbol located)",
            )
        return None

    if patch.name == "force_patreon_token_check_authorized":
        if data[offset:offset + len(patch.expected)] == patch.expected:
            return Patch(
                patch.name,
                offset,
                data[offset:offset + len(patch.replacement)],
                patch.replacement,
                patch.reason + " (symbol located)",
            )
        return None

    if patch.name == "dvn_patreon_logout_noop":
        if data[offset:offset + 4] == patch.replacement:
            return Patch(patch.name, offset, patch.replacement, patch.replacement, patch.reason)
        if (
            offset + 12 <= len(data)
            and is_adrp(read_u32_at(data, offset))
            and data[offset + 4:offset + 12] == bytes.fromhex("2900805209851339")
        ):
            return Patch(
                patch.name,
                offset,
                data[offset:offset + 4],
                patch.replacement,
                patch.reason + " (symbol located)",
            )
        return None

    if patch.name in {"dvn_patreon_login_noop", "dvn_patreon_open_devices_noop"}:
        if data[offset:offset + 4] == patch.replacement:
            return Patch(patch.name, offset, patch.replacement, patch.replacement, patch.reason)
        if is_sub_sp_sp_imm(read_u32_at(data, offset)):
            return Patch(
                patch.name,
                offset,
                data[offset:offset + 4],
                patch.replacement,
                patch.reason + " (symbol located)",
            )
        return None

    return None


def runtime_gate_patch(data: bytes, patch: Patch, info: MachOInfo) -> Patch | None:
    ytp_bool = info.symbols.get("_ytpBool")
    ytp_int = info.symbols.get("_ytpInt")
    if ytp_bool is None or ytp_int is None or ytp_bool >= ytp_int:
        return None

    candidates = [
        offset for offset in info.function_starts
        if ytp_bool < offset < ytp_int
    ]
    for offset in candidates:
        if data[offset:offset + len(patch.replacement)] == patch.replacement:
            return Patch(patch.name, offset, patch.replacement, patch.replacement, patch.reason)
        if (
            offset + len(patch.replacement) <= len(data)
            and is_sub_sp_sp_imm(read_u32_at(data, offset))
        ):
            return Patch(
                patch.name,
                offset,
                data[offset:offset + len(patch.replacement)],
                patch.replacement,
                patch.reason + " (function-start located)",
            )
    return None


def registration_flag_patch(data: bytes, patch: Patch, info: MachOInfo) -> Patch | None:
    locked = info.symbols.get("_dvnLocked")
    if locked is None or locked + 8 > len(data):
        return None

    pc = info.offset_to_vm(locked)
    if pc is None:
        return None

    page = decode_adrp_target(read_u32_at(data, locked), pc)
    ldrb = decode_ldrb_unsigned_immediate(read_u32_at(data, locked + 4))
    if page is None or ldrb is None:
        return None

    imm, rn, rt = ldrb
    adrp_rd = read_u32_at(data, locked) & 0x1F
    if rn != adrp_rd or rt != 8:
        return None

    registration_byte_offset = info.vm_to_offset(page + imm - 1)
    if registration_byte_offset is None:
        return None

    current = data[registration_byte_offset:registration_byte_offset + 1]
    if current not in {patch.expected, patch.replacement}:
        return None

    return Patch(
        patch.name,
        registration_byte_offset,
        current,
        patch.replacement,
        patch.reason + " (flag derived from _dvnLocked)",
    )


def dynamic_patch(data: bytes, patch: Patch, info: MachOInfo) -> Patch | None:
    if patch.name == "skip_build_patreon_section_in_root_table":
        return dynamic_root_build_patch(data, patch)
    if patch.name == "skip_add_patreon_section_to_root_table":
        return dynamic_root_add_patch(data, patch)
    if patch.name == "force_patreon_runtime_gate_authorized":
        return runtime_gate_patch(data, patch, info)
    if patch.name == "default_patreon_block_registration_ready":
        return registration_flag_patch(data, patch, info)
    return symbol_patch(data, patch, info)


def fixed_patch_usable(data: bytes, patch: Patch) -> bool:
    expected_end = patch.offset + len(patch.expected)
    replacement_end = patch.offset + len(patch.replacement)
    if expected_end > len(data) or replacement_end > len(data):
        return False
    return (
        data[patch.offset:expected_end] == patch.expected
        or data[patch.offset:replacement_end] == patch.replacement
    )


def resolve_patches(data: bytes) -> list[Patch]:
    info = parse_macho_info(data)
    resolved: list[Patch] = []

    for patch in PATCHES:
        chosen: Patch | None = None

        # Always honor the reviewed fixed site first when it already contains
        # either the original bytes or our replacement. This keeps the patcher
        # idempotent and avoids a broad dynamic pattern matching an unrelated
        # similar instruction sequence on an already patched file.
        if fixed_patch_usable(data, patch):
            chosen = patch

        if chosen is None:
            chosen = dynamic_patch(data, patch, info)

        if chosen is None:
            raise RuntimeError(
                f"{patch.name}: could not locate a safe patch site for this build."
            )
        resolved.append(chosen)

    return resolved


def apply_patches_to_dylib_bytes(raw: bytes, force: bool = False) -> tuple[bytes, list[str]]:
    if len(raw) < 4 or read_u32(raw, 0) != 0xFEEDFACF:
        raise RuntimeError("Target is not a little-endian 64-bit Mach-O dylib.")

    data = bytearray(raw)
    results: list[str] = []
    patches = PATCHES if force else resolve_patches(bytes(data))

    for patch in patches:
        expected_end = patch.offset + len(patch.expected)
        replacement_end = patch.offset + len(patch.replacement)
        if expected_end > len(data) or replacement_end > len(data):
            raise RuntimeError(
                f"{patch.name}: offset 0x{patch.offset:x} is outside the dylib."
            )

        current = bytes(data[patch.offset:expected_end])
        current_replacement = bytes(data[patch.offset:replacement_end])

        if current_replacement == patch.replacement:
            results.append(f"already patched: {patch.name} @ 0x{patch.offset:x}")
            continue

        if current != patch.expected:
            msg = (
                f"{patch.name}: expected bytes do not match at 0x{patch.offset:x}. "
                f"Found {current.hex()}, expected {patch.expected.hex()}."
            )
            if not force:
                raise RuntimeError(msg)
            results.append(
                f"forced patch despite mismatch: {patch.name} @ 0x{patch.offset:x}"
            )
        else:
            results.append(f"patched: {patch.name} @ 0x{patch.offset:x}")

        data[patch.offset:replacement_end] = patch.replacement

    return bytes(data), results


def patch_dylib_payload(raw: bytes, target: str, force: bool) -> tuple[bytes, PatchReport]:
    patched, results = apply_patches_to_dylib_bytes(raw, force=force)
    code_sig = detect_code_signature(patched)
    if code_sig:
        dataoff, datasize = code_sig
        results.append(
            "note: LC_CODE_SIGNATURE present "
            f"(dataoff=0x{dataoff:x}, datasize=0x{datasize:x}); re-sign after patching"
        )
    return patched, PatchReport(
        target=target,
        output_md5=md5_bytes(patched),
        input_sha256=sha256_bytes(raw),
        output_sha256=sha256_bytes(patched),
        results=results,
    )


def default_output_path(input_path: Path) -> Path:
    return input_path.with_name(f"{input_path.stem}-no-patreon{input_path.suffix}")


def ensure_output_path(input_path: Path, output_path: Path | None) -> Path:
    out = output_path or default_output_path(input_path)
    if input_path.resolve() == out.resolve():
        raise ValueError("Refusing to patch in place; choose a different output path.")
    out.parent.mkdir(parents=True, exist_ok=True)
    return out


def is_target_dylib_path(path: str) -> bool:
    return Path(path.replace("\\", "/")).name == TARGET_DYLIB_NAME


def copy_zip_info(info: zipfile.ZipInfo) -> zipfile.ZipInfo:
    copied = zipfile.ZipInfo(info.filename, date_time=info.date_time)
    copied.comment = info.comment
    copied.extra = info.extra
    copied.internal_attr = info.internal_attr
    copied.external_attr = info.external_attr
    copied.create_system = info.create_system
    copied.create_version = info.create_version
    copied.extract_version = info.extract_version
    copied.flag_bits = info.flag_bits & ~0x1
    copied.volume = info.volume
    copied.compress_type = info.compress_type
    return copied


def patch_dylib_file(input_path: Path, output_path: Path, force: bool) -> list[PatchReport]:
    raw = input_path.read_bytes()
    patched, report = patch_dylib_payload(raw, input_path.name, force)
    output_path.write_bytes(patched)
    return [report]


def patch_ipa(input_path: Path, output_path: Path, force: bool) -> list[PatchReport]:
    reports: list[PatchReport] = []

    with zipfile.ZipFile(input_path, "r") as zin:
        target_names = [
            info.filename
            for info in zin.infolist()
            if not info.is_dir() and is_target_dylib_path(info.filename)
        ]
        if not target_names:
            raise RuntimeError(f"No {TARGET_DYLIB_NAME} found inside IPA.")

        with tempfile.NamedTemporaryFile(
            prefix=output_path.stem + ".",
            suffix=output_path.suffix,
            dir=str(output_path.parent),
            delete=False,
        ) as tmp:
            temp_path = Path(tmp.name)

        try:
            with zipfile.ZipFile(temp_path, "w", allowZip64=True) as zout:
                zout.comment = zin.comment
                for info in zin.infolist():
                    payload = zin.read(info)
                    out_info = copy_zip_info(info)

                    if info.filename in target_names:
                        payload, report = patch_dylib_payload(
                            payload, info.filename, force
                        )
                        reports.append(report)

                    zout.writestr(out_info, payload, compress_type=info.compress_type)
            temp_path.replace(output_path)
        except Exception:
            temp_path.unlink(missing_ok=True)
            raise

    return reports


def ar_member_name(name_field: bytes, data: bytes) -> tuple[str, bytes]:
    raw = name_field.decode("utf-8", errors="replace").rstrip()
    if raw.startswith("#1/"):
        name_len = int(raw[3:])
        name = data[:name_len].decode("utf-8", errors="replace")
        return name, data[name_len:]
    if raw.endswith("/"):
        raw = raw[:-1]
    return raw, data


def parse_ar(raw: bytes) -> list[ArMember]:
    if not raw.startswith(b"!<arch>\n"):
        raise RuntimeError("Input is not a Debian ar archive.")

    members: list[ArMember] = []
    offset = 8
    while offset < len(raw):
        if offset + 60 > len(raw):
            raise RuntimeError("Invalid ar archive: truncated member header.")
        header = raw[offset:offset + 60]
        offset += 60

        if header[58:60] != b"`\n":
            raise RuntimeError("Invalid ar archive: bad member magic.")

        size = int(header[48:58].decode("ascii").strip() or "0")
        payload = raw[offset:offset + size]
        if len(payload) != size:
            raise RuntimeError("Invalid ar archive: truncated member payload.")
        offset += size
        if size % 2:
            offset += 1

        name, payload = ar_member_name(header[0:16], payload)
        members.append(
            ArMember(
                name=name,
                name_field=header[0:16],
                mtime_field=header[16:28],
                uid_field=header[28:34],
                gid_field=header[34:40],
                mode_field=header[40:48],
                data=payload,
            )
        )

    return members


def build_ar(members: list[ArMember]) -> bytes:
    out = bytearray(b"!<arch>\n")
    for member in members:
        size_field = f"{len(member.data):<10}".encode("ascii")
        if len(size_field) != 10:
            raise RuntimeError(f"ar member is too large: {member.name}")
        header = (
            member.name_field
            + member.mtime_field
            + member.uid_field
            + member.gid_field
            + member.mode_field
            + size_field
            + b"`\n"
        )
        if len(header) != 60:
            raise RuntimeError(f"Invalid ar header length for {member.name}.")
        out.extend(header)
        out.extend(member.data)
        if len(member.data) % 2:
            out.extend(b"\n")
    return bytes(out)


def compression_from_data_member(name: str) -> str:
    lower = name.lower()
    if lower.endswith(".tar"):
        return "none"
    if lower.endswith(".tar.gz") or lower.endswith(".tgz"):
        return "gz"
    if lower.endswith(".tar.xz"):
        return "xz"
    if lower.endswith(".tar.bz2"):
        return "bz2"
    if lower.endswith(".tar.lzma"):
        return "lzma"
    if lower.endswith(".tar.zst"):
        return "zst"
    raise RuntimeError(f"Unsupported Debian data archive compression: {name}")


def zstd_decompress(payload: bytes) -> bytes:
    try:
        import zstandard as zstd  # type: ignore

        return zstd.ZstdDecompressor().decompress(payload)
    except ImportError:
        zstd_exe = shutil.which("zstd") or shutil.which("zstd.exe")
        if not zstd_exe:
            raise RuntimeError(
                "data.tar.zst requires the 'zstandard' Python package or zstd.exe."
            )
        proc = subprocess.run(
            [zstd_exe, "-d", "-q", "-c"],
            input=payload,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
        return proc.stdout


def zstd_compress(payload: bytes) -> bytes:
    try:
        import zstandard as zstd  # type: ignore

        return zstd.ZstdCompressor(level=19).compress(payload)
    except ImportError:
        zstd_exe = shutil.which("zstd") or shutil.which("zstd.exe")
        if not zstd_exe:
            raise RuntimeError(
                "data.tar.zst requires the 'zstandard' Python package or zstd.exe."
            )
        proc = subprocess.run(
            [zstd_exe, "-q", "-19", "-c"],
            input=payload,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True,
        )
        return proc.stdout


def decompress_tar(payload: bytes, compression: str) -> bytes:
    if compression == "none":
        return payload
    if compression == "gz":
        return gzip.decompress(payload)
    if compression == "xz":
        return lzma.decompress(payload, format=lzma.FORMAT_XZ)
    if compression == "bz2":
        return bz2.decompress(payload)
    if compression == "lzma":
        return lzma.decompress(payload, format=lzma.FORMAT_ALONE)
    if compression == "zst":
        return zstd_decompress(payload)
    raise RuntimeError(f"Unsupported compression: {compression}")


def compress_tar(payload: bytes, compression: str) -> bytes:
    if compression == "none":
        return payload
    if compression == "gz":
        return gzip.compress(payload, compresslevel=9, mtime=0)
    if compression == "xz":
        return lzma.compress(payload, format=lzma.FORMAT_XZ, preset=9)
    if compression == "bz2":
        return bz2.compress(payload, compresslevel=9)
    if compression == "lzma":
        return lzma.compress(payload, format=lzma.FORMAT_ALONE, preset=9)
    if compression == "zst":
        return zstd_compress(payload)
    raise RuntimeError(f"Unsupported compression: {compression}")


def normalize_tar_path(path: str) -> str:
    normalized = path.replace("\\", "/")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    return normalized.lstrip("/")


def patch_tar_payload(
    raw_tar: bytes,
    force: bool,
) -> tuple[bytes, list[PatchReport], dict[str, str]]:
    reports: list[PatchReport] = []
    md5sums: dict[str, str] = {}
    out_io = io.BytesIO()

    with tarfile.open(fileobj=io.BytesIO(raw_tar), mode="r:") as tin:
        with tarfile.open(fileobj=out_io, mode="w", format=tin.format) as tout:
            for member in tin.getmembers():
                source = tin.extractfile(member) if member.isfile() else None
                payload = source.read() if source is not None else None
                out_member = copy.copy(member)

                if member.isfile() and is_target_dylib_path(member.name):
                    if payload is None:
                        raise RuntimeError(f"Could not read {member.name} from tar.")
                    payload, report = patch_dylib_payload(payload, member.name, force)
                    out_member.size = len(payload)
                    reports.append(report)
                    md5sums[normalize_tar_path(member.name)] = report.output_md5

                if payload is None:
                    tout.addfile(out_member)
                else:
                    tout.addfile(out_member, io.BytesIO(payload))

    if not reports:
        raise RuntimeError(f"No {TARGET_DYLIB_NAME} found inside Debian data archive.")

    return out_io.getvalue(), reports, md5sums


def patch_control_md5sums(raw_tar: bytes, patched_md5s: dict[str, str]) -> tuple[bytes, bool]:
    out_io = io.BytesIO()
    changed = False
    found_md5sums = False

    with tarfile.open(fileobj=io.BytesIO(raw_tar), mode="r:") as tin:
        with tarfile.open(fileobj=out_io, mode="w", format=tin.format) as tout:
            for member in tin.getmembers():
                source = tin.extractfile(member) if member.isfile() else None
                payload = source.read() if source is not None else None
                out_member = copy.copy(member)

                if member.isfile() and normalize_tar_path(member.name) == "md5sums":
                    found_md5sums = True
                    text = (payload or b"").decode("utf-8", errors="replace")
                    new_lines: list[str] = []
                    seen_paths: set[str] = set()

                    for line in text.splitlines(keepends=True):
                        line_body = line.rstrip("\r\n")
                        newline = line[len(line_body):]
                        parts = line_body.split(None, 1)
                        if len(parts) == 2:
                            listed_path = parts[1].strip()
                            normalized = normalize_tar_path(listed_path)
                            if normalized in patched_md5s:
                                new_lines.append(
                                    f"{patched_md5s[normalized]}  {listed_path}{newline or chr(10)}"
                                )
                                seen_paths.add(normalized)
                                changed = True
                                continue
                        new_lines.append(line)

                    for normalized, digest in patched_md5s.items():
                        if normalized not in seen_paths:
                            new_lines.append(f"{digest}  {normalized}\n")
                            changed = True

                    if changed:
                        payload = "".join(new_lines).encode("utf-8")
                        out_member.size = len(payload)

                if payload is None:
                    tout.addfile(out_member)
                else:
                    tout.addfile(out_member, io.BytesIO(payload))

    if not found_md5sums:
        return raw_tar, False
    if not changed:
        return raw_tar, False
    return out_io.getvalue(), True


def patch_deb(input_path: Path, output_path: Path, force: bool) -> list[PatchReport]:
    members = parse_ar(input_path.read_bytes())
    data_members = [
        member for member in members
        if member.name.startswith("data.tar") or Path(member.name).name.startswith("data.tar")
    ]
    if len(data_members) != 1:
        raise RuntimeError(f"Expected one data.tar.* member, found {len(data_members)}.")

    data_member = data_members[0]
    compression = compression_from_data_member(data_member.name)
    raw_tar = decompress_tar(data_member.data, compression)
    patched_tar, reports, patched_md5s = patch_tar_payload(raw_tar, force)
    data_member.data = compress_tar(patched_tar, compression)

    control_members = [
        member for member in members
        if member.name.startswith("control.tar")
        or Path(member.name).name.startswith("control.tar")
    ]
    if len(control_members) == 1:
        control_member = control_members[0]
        control_compression = compression_from_data_member(control_member.name)
        raw_control_tar = decompress_tar(control_member.data, control_compression)
        patched_control_tar, control_changed = patch_control_md5sums(
            raw_control_tar,
            patched_md5s,
        )
        if control_changed:
            control_member.data = compress_tar(patched_control_tar, control_compression)
            reports[0].results.append("note: updated DEB control md5sums")
        else:
            reports[0].results.append("note: no DEB control md5sums update needed")
    else:
        reports[0].results.append(
            f"note: expected one control.tar.* member for md5 update, found {len(control_members)}"
        )

    with tempfile.NamedTemporaryFile(
        prefix=output_path.stem + ".",
        suffix=output_path.suffix,
        dir=str(output_path.parent),
        delete=False,
    ) as tmp:
        temp_path = Path(tmp.name)

    try:
        temp_path.write_bytes(build_ar(members))
        temp_path.replace(output_path)
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise

    return reports


def choose_input_file() -> Path | None:
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        selected = filedialog.askopenfilename(
            title="Select IPA, DEB, or YTLite.dylib",
            filetypes=[
                ("Supported files", "*.ipa *.deb *.dylib"),
                ("IPA files", "*.ipa"),
                ("DEB files", "*.deb"),
                ("Dylib files", "*.dylib"),
                ("All files", "*.*"),
            ],
        )
        root.destroy()
        return Path(selected) if selected else None
    except Exception:
        value = input("Input .ipa/.deb/.dylib path: ").strip().strip('"')
        return Path(value) if value else None


def print_reports(reports: list[PatchReport]) -> None:
    for report in reports:
        print(f"Target: {report.target}")
        print(f"  input SHA-256:  {report.input_sha256}")
        print(f"  output SHA-256: {report.output_sha256}")
        for result in report.results:
            print(f"  - {result}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Patch YTLite.dylib inside a .dylib, .ipa, or .deb and write a "
            "new no-patreon output file."
        )
    )
    parser.add_argument(
        "input",
        nargs="?",
        help="Input .dylib, .ipa, or .deb. Omit to open a file picker.",
    )
    parser.add_argument(
        "-o",
        "--output",
        help="Output path. Default: <input-stem>-no-patreon<same-extension>.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Apply patches even if expected bytes do not match.",
    )
    args = parser.parse_args()

    input_path = Path(args.input) if args.input else choose_input_file()
    if input_path is None:
        print("No input selected.")
        return 2

    input_path = input_path.expanduser().resolve()
    if not input_path.is_file():
        raise FileNotFoundError(f"Input file does not exist: {input_path}")

    output_path = ensure_output_path(
        input_path,
        Path(args.output).expanduser().resolve() if args.output else None,
    )

    suffix = input_path.suffix.lower()
    print(f"Input:  {input_path}")
    print(f"Output: {output_path}")
    print(f"Package input SHA-256: {sha256_file(input_path)}")

    if suffix == ".dylib":
        reports = patch_dylib_file(input_path, output_path, args.force)
    elif suffix == ".ipa":
        reports = patch_ipa(input_path, output_path, args.force)
    elif suffix == ".deb":
        reports = patch_deb(input_path, output_path, args.force)
    else:
        raise RuntimeError("Supported input extensions are .dylib, .ipa, and .deb.")

    print(f"Package output SHA-256: {sha256_file(output_path)}")
    print_reports(reports)
    print("Done. Re-sign the patched dylib/app/package for the target environment.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(1)
