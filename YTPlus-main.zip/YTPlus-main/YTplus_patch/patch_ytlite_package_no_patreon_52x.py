#!/usr/bin/env python3
"""Compatibility wrapper for the YTLite no-patreon package patcher.

This keeps the original patch_ytlite_package_no_patreon.py untouched and adds
extra locator tolerance for 5.2.1-style builds where a few Patreon-related
functions moved or changed their immediate offsets.
"""

from __future__ import annotations

import sys

import patch_ytlite_package_no_patreon as base


KNOWN_INPUT_SHA256S = {
    "406451ed1ca39f66d58fe2b1155015ec545345a865f07d5488f01568cff6774f",
    "aff5898c39c79880981501aa198f703b4871255dc21e073c99c92cc49d90f7f2",
}


def decode_strb_unsigned_immediate(word: int) -> tuple[int, int, int] | None:
    if (word & 0xFFC00000) != 0x39000000:
        return None
    imm = (word >> 10) & 0xFFF
    rn = (word >> 5) & 0x1F
    rt = word & 0x1F
    return imm, rn, rt


def matches_dvn_locked_body(data: bytes, offset: int) -> bool:
    if offset + 20 > len(data):
        return False
    adrp = base.read_u32_at(data, offset)
    if not base.is_adrp(adrp):
        return False

    ldrb = base.decode_ldrb_unsigned_immediate(base.read_u32_at(data, offset + 4))
    if ldrb is None:
        return False

    _imm, rn, rt = ldrb
    adrp_rd = adrp & 0x1F
    if rn != adrp_rd or rt != 8:
        return False

    return data[offset + 8:offset + 20] == bytes.fromhex(
        "290080522001280ac0035fd6"
    )


def find_logout_body_offset(
    data: bytes,
    symbol_offset: int,
    search_bytes: int = 0x20,
) -> int | None:
    end = min(len(data), symbol_offset + search_bytes)
    for offset in range(symbol_offset, end - 12 + 1, 4):
        adrp = base.read_u32_at(data, offset)
        if not base.is_adrp(adrp):
            continue
        if data[offset + 4:offset + 8] != bytes.fromhex("29008052"):
            continue

        strb = decode_strb_unsigned_immediate(base.read_u32_at(data, offset + 8))
        if strb is None:
            continue

        _imm, rn, rt = strb
        adrp_rd = adrp & 0x1F
        if rn == adrp_rd and rt == 9:
            return offset

    return None


ORIGINAL_DYNAMIC_ROOT_PAIR = base.dynamic_root_pair
ORIGINAL_REGISTRATION_FLAG_PATCH = base.registration_flag_patch
ORIGINAL_SYMBOL_PATCH = base.symbol_patch
ORIGINAL_APPLY_PATCHES_TO_DYLIB_BYTES = base.apply_patches_to_dylib_bytes

OPTIONAL_PATCHES = [
    base.Patch(
        name="keep_startup_patreon_failure_from_relocking_auth",
        offset=0x27510,
        expected=bytes.fromhex("29008052"),
        replacement=bytes.fromhex("09008052"),
        reason=(
            "Keep the 5.2.1 startup Patreon failure path from re-locking the auth byte."
        ),
    ),
    base.Patch(
        name="suppress_features_not_activated_popup",
        offset=0x4F878,
        expected=bytes.fromhex("ff4302d1"),
        replacement=base.AARCH64_RET,
        reason="Suppress the launch-time Patreon access reminder popup.",
    ),
]


def dynamic_root_pair(data: bytes) -> tuple[int, int] | None:
    pair = ORIGINAL_DYNAMIC_ROOT_PAIR(data)
    if pair is not None:
        return pair

    build_pattern = base.AARCH64_NOP * 5 + base.AARCH64_MOV_X19_ZERO
    add_pattern = base.AARCH64_NOP * 3
    for build_offset in base.find_masked(
        data,
        build_pattern,
        b"\xff" * len(build_pattern),
    ):
        add_matches = base.find_masked(
            data,
            add_pattern,
            b"\xff" * len(add_pattern),
            start=build_offset + 0x20,
            end=build_offset + 0x80,
        )
        if add_matches:
            return build_offset, add_matches[0]

    return None


def symbol_patch(data: bytes, patch: base.Patch, info: base.MachOInfo) -> base.Patch | None:
    if patch.name == "force_patreon_flag_check_authorized":
        offset = info.symbols.get("_dvnLocked")
        if offset is None:
            return None
        if data[offset:offset + len(patch.replacement)] == patch.replacement:
            return base.Patch(
                patch.name,
                offset,
                patch.replacement,
                patch.replacement,
                patch.reason,
            )
        if matches_dvn_locked_body(data, offset):
            return base.Patch(
                patch.name,
                offset,
                data[offset:offset + len(patch.replacement)],
                patch.replacement,
                patch.reason + " (symbol located, 5.2.x-compatible)",
            )
        return None

    if patch.name == "force_patreon_token_check_authorized":
        offset = info.symbols.get("_dvnCheck")
        if offset is None:
            return None
        if data[offset:offset + len(patch.replacement)] == patch.replacement:
            return base.Patch(
                patch.name,
                offset,
                patch.replacement,
                patch.replacement,
                patch.reason,
            )
        return ORIGINAL_SYMBOL_PATCH(data, patch, info)

    if patch.name == "dvn_patreon_logout_noop":
        offset = info.symbols.get("_DVNPatreonLogout")
        if offset is None:
            return None
        if data[offset:offset + 4] == patch.replacement:
            return base.Patch(
                patch.name,
                offset,
                patch.replacement,
                patch.replacement,
                patch.reason,
            )
        if find_logout_body_offset(data, offset) is not None:
            return base.Patch(
                patch.name,
                offset,
                data[offset:offset + 4],
                patch.replacement,
                patch.reason + " (symbol located, 5.2.x-compatible)",
            )
        return None

    return ORIGINAL_SYMBOL_PATCH(data, patch, info)


def registration_flag_patch(
    data: bytes,
    patch: base.Patch,
    info: base.MachOInfo,
) -> base.Patch | None:
    resolved = ORIGINAL_REGISTRATION_FLAG_PATCH(data, patch, info)
    if resolved is not None:
        return resolved

    logout = info.symbols.get("_DVNPatreonLogout")
    if logout is None:
        return None

    body_offset = find_logout_body_offset(data, logout)
    if body_offset is None:
        return None

    pc = info.offset_to_vm(body_offset)
    if pc is None:
        return None

    page = base.decode_adrp_target(base.read_u32_at(data, body_offset), pc)
    strb = decode_strb_unsigned_immediate(base.read_u32_at(data, body_offset + 8))
    if page is None or strb is None:
        return None

    imm, rn, rt = strb
    adrp_rd = base.read_u32_at(data, body_offset) & 0x1F
    if rn != adrp_rd or rt != 9:
        return None

    registration_byte_offset = info.vm_to_offset(page + imm - 1)
    if registration_byte_offset is None:
        return None

    current = data[registration_byte_offset:registration_byte_offset + 1]
    if current not in {patch.expected, patch.replacement}:
        return None

    return base.Patch(
        patch.name,
        registration_byte_offset,
        current,
        patch.replacement,
        patch.reason + " (flag derived from logout body, 5.2.x-compatible)",
    )


def apply_optional_patches_to_results(data: bytearray, results: list[str]) -> None:
    for patch in OPTIONAL_PATCHES:
        replacement_end = patch.offset + len(patch.replacement)
        expected_end = patch.offset + len(patch.expected)
        if replacement_end > len(data) or expected_end > len(data):
            continue

        current_replacement = bytes(data[patch.offset:replacement_end])
        if current_replacement == patch.replacement:
            results.append(f"already patched: {patch.name} @ 0x{patch.offset:x}")
            continue

        current = bytes(data[patch.offset:expected_end])
        if current != patch.expected:
            continue

        data[patch.offset:replacement_end] = patch.replacement
        results.append(f"patched: {patch.name} @ 0x{patch.offset:x}")


def apply_patches_to_dylib_bytes(raw: bytes, force: bool = False) -> tuple[bytes, list[str]]:
    patched, results = ORIGINAL_APPLY_PATCHES_TO_DYLIB_BYTES(raw, force=force)
    data = bytearray(patched)
    apply_optional_patches_to_results(data, results)
    return bytes(data), results


def install_compatibility_hooks() -> None:
    base.dynamic_root_pair = dynamic_root_pair
    base.registration_flag_patch = registration_flag_patch
    base.symbol_patch = symbol_patch
    base.apply_patches_to_dylib_bytes = apply_patches_to_dylib_bytes


def main() -> int:
    install_compatibility_hooks()
    return base.main()


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(1)
      
